LINUX SCP COPY UTILITY for AMD64 or RASPBERRY PI.
Here you will find an utility for copy with SCP from one computer to another in a LAN.
The Binaries are for Ubuntu/AMD64 or Raspberry PI as well.
You should extract  the files to: /usr/bin. This is the default directory.

Start the program with:
myscp <file> <target-no>
myscp sample.txt 2
The possible targets are stored in /usr/bin/myscp.txt
myscp n  starts the nano editor for myscp.txt
The first entry is the numbers of the targets.
example
6
root@192.168.1.102:/root/icon
root@192.168.1.102:/var/www
root@192.168.1.106:/root
ubu@192.168.1.121:/home/ubu/Desktop
root@192.168.1.127:/root
kl@192.168.1.100:/home/kl/ip106

The system needs the file iconx to run.

The program is written in ICON.
For more information, see the Icon website:
www.cs.arizona.edu/icon

Have fun
